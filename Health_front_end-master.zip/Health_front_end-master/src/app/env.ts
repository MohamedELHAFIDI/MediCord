//env variables
export const env = {
    "url": "http://localhost:8080/api"
}
