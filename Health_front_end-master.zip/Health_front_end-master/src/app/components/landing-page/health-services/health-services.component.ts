import { Component } from '@angular/core';

@Component({
  selector: 'app-health-services',
  templateUrl: './health-services.component.html',
  styleUrls: ['./health-services.component.scss']
})
export class HealthServicesComponent {

}
