package com.example.backEndProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackEndProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackEndProjectApplication.class, args);
	}

}
