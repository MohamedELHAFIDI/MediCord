package com.example.backEndProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackEndProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
